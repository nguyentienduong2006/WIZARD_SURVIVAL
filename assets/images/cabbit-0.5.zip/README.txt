Name:
  Cabbit Collection
Version:
  0.5
Description:
  A collection of sprites created by, or based on the work of, Svetlana Kushnariova (Cabbit).
Licensing:
  - OpenGameArt.org Attribution (OGA BY) version 3.0 or later (see: LICENSE-OGA-BY-3.0.txt)
  - Creative Commons Attribution (CC BY) version 3.0 or later (see: LICENSE-CC-BY-3.0.txt)
Copyright/Attribution:
  Created by Svetlana Kushnariova (Cabbit) <lana-chan@yandex.ru>, diamonddmgirl, & Jordan Irwin (AntumDeluge)
Links:
  - OpenGameArt.org page: https://opengameart.org/node/79804
  - For links to Cabbit's & diamonddmgirl's submissions, see sources.md file.
Notes:
  - IMPORTANT: As part of Cabbit's attribution requirements, please credit her as "Svetlana Kushnariova"
    & include her email address: lana-chan@yandex.ru
