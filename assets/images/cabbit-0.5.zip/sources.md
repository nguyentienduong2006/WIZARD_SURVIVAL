### Cabbit Collection Sources:

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
    </tr>
    <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>

- (OGA BY 3.0 / CC BY 3.0)
  - [24x32 Black Character Pack](https://opengameart.org/node/72198) by Cabbit & diamonddgirl
  - [24x32 characters, 16x16 tiles](https://opengameart.org/node/72969) by Cabbit
  - [24x32 Characters Lying Down](https://opengameart.org/node/72611) by Cabbit & diamonddgirl
  - [24x32 characters with faces (big pack)](https://opengameart.org/node/24823) by Cabbit
  - [24x32 heroine Lyuba (sprites, faces, pictures)](https://opengameart.org/node/50909) by Cabbit
  - [Edited and Extended 24x32 Character Pack](https://opengameart.org/node/66147) by Cabbit & diamonddgirl
